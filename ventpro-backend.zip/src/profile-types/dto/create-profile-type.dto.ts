export class CreateProfileTypeDto {}
