export class WindowCalculation {}
