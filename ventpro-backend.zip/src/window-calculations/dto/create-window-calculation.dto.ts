export class CreateWindowCalculationDto {}
