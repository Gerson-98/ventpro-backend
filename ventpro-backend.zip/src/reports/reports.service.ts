// RUTA: src/reports/reports.service.ts

import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
// CAMBIO: 'windows as Window' -> 'Window' (el modelo ahora se llama Window en PascalCase)
import { Window, Material, AccessoryRule } from '@prisma/client';

type AccessoryRuleWithMaterial = AccessoryRule & { material: Material };

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  private async processWindowsToReport(windows: any[]) {
    const allMaterials = await this.prisma.material.findMany();
    const materialsMap = new Map(allMaterials.map((m) => [m.name, m]));

    // CAMBIO: catalogo_perfiles -> catalogoPerfiles
    // CAMBIO: perfil_marco -> perfilMarco, etc.
    // CAMBIO: map key usa window_type_id en lugar de tipo_ventana
    const catalogMap = new Map(
      (
        await this.prisma.catalogoPerfiles.findMany({
          include: {
            perfilMarco: true,
            perfilHoja: true,
            perfilMosquitero: true,
            perfilBatiente: true,
            perfilTapajamba: true,
          },
        })
      ).map((p) => [p.window_type_id, p]),
    );

    const accessoryRules: AccessoryRuleWithMaterial[] =
      await this.prisma.accessoryRule.findMany({
        include: { material: true },
      });

    const rulesByWindowType = new Map<number, AccessoryRuleWithMaterial[]>();
    accessoryRules.forEach((rule) => {
      if (!rulesByWindowType.has(rule.window_type_id))
        rulesByWindowType.set(rule.window_type_id, []);
      rulesByWindowType.get(rule.window_type_id)!.push(rule);
    });

    const profilesReportMap = new Map<string, any>();
    const accessoriesReportMap = new Map<string, any>();
    const glassReportMap = new Map<string, any>();

    for (const window of windows) {
      // CAMBIO: window.window_type -> window.windowType
      if (!window || !window.windowType || !window.pvcColor) continue;

      // CAMBIO: catalogMap ahora indexado por window_type_id
      const catalogEntry = catalogMap.get(window.window_type_id);
      if (!catalogEntry) continue;

      const windowQuantity = window.quantity || 1;
      const options = (window.options as any) || {};

      // CAMBIO: perfil_marco -> perfilMarco, regla_marco -> regla_marco (estas no cambiaron)
      let dynamicProfiles = [
        {
          type: 'MARCO',
          material: catalogEntry.perfilMarco,
          rule: catalogEntry.regla_marco,
        },
        {
          type: 'HOJA',
          material: catalogEntry.perfilHoja,
          rule: catalogEntry.regla_hoja,
        },
        {
          type: 'MOSQUITERO',
          material: catalogEntry.perfilMosquitero,
          rule: catalogEntry.regla_mosquitero,
        },
        {
          type: 'BATIENTE',
          material: catalogEntry.perfilBatiente,
          rule: catalogEntry.regla_batiente,
        },
        {
          type: 'TAPAJAMBA',
          material: catalogEntry.perfilTapajamba,
          rule: catalogEntry.regla_tapajamba,
        },
      ];

      const isDuela = window.glassColor?.name.toUpperCase().includes('DUELA');

      // CAMBIO: window.window_type.name -> window.windowType.name
      switch (window.windowType.name) {
        case 'PUERTA CORREDIZA 2 HOJAS 66 CM MARCO 45 CM':
        case 'VENTANA CORREDIZA 2 HOJAS 55 CM MARCO 45 CM':
        case 'VENTANA CORREDIZA 2 HOJAS 55 CM MARCO 5 CM':
        case 'VENTANA CORREDIZA 4 HOJAS 55 CM MARCO 45 CM':
        case 'VENTANA CORREDIZA 4 HOJAS 55 CM MARCO 5 CM':
        case 'PUERTA CORREDIZA 3 HOJAS 66 CM MARCO 45 CM':
        case 'PUERTA CORREDIZA 3 HOJAS 66 CM MARCO 5 CM':
        case 'VENTANA CORREDIZA 3 HOJAS 55 CM MARCO 45 CM':
        case 'VENTANA CORREDIZA 3 HOJAS 55 CM MARCO 5 CM':
        case 'PUERTA CORREDIZA 4 HOJAS 66 CM MARCO 45 CM':
        case 'PUERTA CORREDIZA 4 HOJAS 66 CM MARCO 5 CM':
          if (isDuela) {
            const batienteCorredizo = materialsMap.get('BATIENTE CORREDIZO');
            const batienteInsulado = materialsMap.get('BATIENTE INSULADO');
            if (batienteCorredizo && batienteInsulado) {
              dynamicProfiles = dynamicProfiles.map((p) =>
                p.material?.id === batienteCorredizo.id
                  ? { ...p, material: batienteInsulado }
                  : p,
              );
            }
          }
          break;
        case 'PUERTA ANDINA':
          if (window.glassColor?.name.toUpperCase() === 'VIDRIO Y DUELA') {
            const batienteParaDuela = materialsMap.get('BATIENTE PARA DUELA');
            if (batienteParaDuela && catalogEntry.regla_batiente) {
              dynamicProfiles.push({
                type: 'BATIENTE',
                material: batienteParaDuela,
                rule: catalogEntry.regla_batiente,
              });
            }
          }
          break;
        case 'VENTANA ABATIBLE':
          const materialHojaAbatible =
            options.tipo_perfil === 'adentro'
              ? materialsMap.get('HOJA ABATIBLE ADENTRO')
              : materialsMap.get('HOJA ABATIBLE AFUERA');
          if (materialHojaAbatible && catalogEntry.regla_hoja) {
            dynamicProfiles = dynamicProfiles.map((p) =>
              p.type === 'HOJA' ? { ...p, material: materialHojaAbatible } : p,
            );
          }
          if (options.cantidad_hojas === '2') {
            const tDeFijo = materialsMap.get('T DE FIJO');
            if (tDeFijo) {
              const key = `${window.pvcColor.name}|${tDeFijo.name}`;
              const existing = profilesReportMap.get(key) || {
                material: tDeFijo,
                pvcColor: window.pvcColor.name,
                totalLength: 0,
              };
              existing.totalLength += window.height_cm * windowQuantity;
              profilesReportMap.set(key, existing);
            }
          }
          break;
      }

      // 1. ACCESORIOS
      if (window.window_type_id) {
        const rules = rulesByWindowType.get(window.window_type_id) || [];
        for (const rule of rules) {
          const shouldAdd =
            !rule.option_group ||
            options[rule.option_group] === rule.option_key;
          if (shouldAdd && rule.material) {
            const key = `${rule.material.name}|${window.pvcColor.name}`;
            const existing = accessoriesReportMap.get(key) || {
              material: rule.material,
              quantity: 0,
              pvcColor: window.pvcColor.name,
              note: '',
            };
            if (rule.material.name === 'LANCETA')
              existing.note = `Cortar a ${window.width_cm} cm`;
            existing.quantity += rule.quantity * windowQuantity;
            accessoriesReportMap.set(key, existing);
          }
        }
      }

      // 2. PERFILES
      for (const profile of dynamicProfiles) {
        if (profile.material && profile.rule) {
          const requiredLength = this.calculateProfileLength(
            profile.rule,
            profile.type,
            window,
          );
          const key = `${window.pvcColor.name}|${profile.material.name}`;
          const existing = profilesReportMap.get(key) || {
            material: profile.material,
            pvcColor: window.pvcColor.name,
            totalLength: 0,
          };
          existing.totalLength += requiredLength * windowQuantity;
          profilesReportMap.set(key, existing);
        }
      }

      // 3. VIDRIOS
      if (window.glassColor) {
        const glassNameUpper = window.glassColor.name.toUpperCase();
        let vAncho = window.vidrioAncho || 0;
        let vAlto = window.vidrioAlto || 0;

        if (vAncho === 0 || vAlto === 0) {
          const reglaBase = catalogEntry.regla_hoja || catalogEntry.regla_marco;
          if (reglaBase) {
            vAncho =
              this.calculateProfileLength(reglaBase, 'ANCHO', window) - 9;
            vAlto = this.calculateProfileLength(reglaBase, 'ALTO', window) - 9;
          }
        }

        if (glassNameUpper.includes('DUELA')) {
          const duelaMaterial = materialsMap.get('DUELA');
          if (duelaMaterial) {
            const stripsNeeded = Math.ceil(vAlto / 15);
            const totalDuelaLength = stripsNeeded * vAncho;
            const key = `${window.pvcColor.name}|${duelaMaterial.name}`;
            const existing = profilesReportMap.get(key) || {
              material: duelaMaterial,
              pvcColor: window.pvcColor.name,
              totalLength: 0,
            };
            existing.totalLength += totalDuelaLength * windowQuantity;
            profilesReportMap.set(key, existing);
          }
        } else if (glassNameUpper !== 'VIDRIO Y DUELA') {
          const glassMaterial = materialsMap.get(window.glassColor.name);
          if (glassMaterial && vAncho > 0 && vAlto > 0) {
            const key = glassMaterial.name;
            const glassCount = catalogEntry.cant_vidrios ?? 1;
            const glassArea = vAncho * vAlto * glassCount * windowQuantity;
            const existing = glassReportMap.get(key) || {
              material: glassMaterial,
              totalArea: 0,
            };
            existing.totalArea += glassArea;
            glassReportMap.set(key, existing);
          }
        }
      }
    }

    const profilesReport = Array.from(profilesReportMap.values()).map(
      (item) => {
        const isWhite = item.pvcColor.toUpperCase().includes('BLANCO');
        const price = isWhite
          ? item.material.price_white
          : item.material.price_color;
        const barras = Math.ceil(item.totalLength / 580);
        return {
          tipo: 'PERFIL',
          nombre: item.material.name,
          color: item.pvcColor,
          cantidad: barras,
          unidad: item.material.unit || 'Barra 5.8m',
          precioUnitario: price || 0,
          precioTotal: (price || 0) * barras,
        };
      },
    );

    const accessoriesReport = Array.from(accessoriesReportMap.values()).map(
      (item) => {
        const isWhite = item.pvcColor.toUpperCase().includes('BLANCO');
        const price = isWhite
          ? item.material.price_white
          : item.material.price_color;
        return {
          tipo: 'ACCESORIO',
          nombre: item.material.name,
          color: isWhite ? 'Blanco' : 'Negro',
          cantidad: item.quantity,
          unidad: item.material.unit || 'Unidades',
          precioUnitario: price || 0,
          precioTotal: (price || 0) * item.quantity,
          note: item.note,
        };
      },
    );

    const glassReport = Array.from(glassReportMap.values()).map((item) => {
      const price = item.material.price_white || item.material.price_color || 0;
      const planchas = Math.ceil(item.totalArea / 35310);
      return {
        tipo: 'VIDRIO',
        nombre: item.material.name,
        color: item.material.name,
        cantidad: planchas,
        unidad: 'Planchas',
        precioUnitario: price,
        precioTotal: price * planchas,
      };
    });

    return [...profilesReport, ...accessoriesReport, ...glassReport].sort(
      (a, b) =>
        a.tipo.localeCompare(b.tipo) ||
        a.color.localeCompare(b.color) ||
        a.nombre.localeCompare(b.nombre),
    );
  }

  async generateProfilesReport(orderId: number) {
    // CAMBIO: orders -> order, window_type -> windowType
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        windows: {
          include: { windowType: true, pvcColor: true, glassColor: true },
        },
      },
    });
    if (!order) throw new NotFoundException(`Pedido #${orderId} no encontrado`);
    return this.processWindowsToReport(order.windows);
  }

  async generateProfilesReportByQuotation(quotationId: number) {
    // CAMBIO: window_type -> windowType
    const quotation = await this.prisma.quotation.findUnique({
      where: { id: quotationId },
      include: {
        quotation_windows: {
          include: {
            windowType: { include: { calculation: true } },
            pvcColor: true,
            glassColor: true,
          },
        },
      },
    });
    if (!quotation)
      throw new NotFoundException(`Cotización #${quotationId} no encontrada`);

    const normalizedWindows = quotation.quotation_windows.map((qw) => {
      // CAMBIO: qw.window_type -> qw.windowType
      const calc = qw.windowType?.calculation;

      const hAncho = calc
        ? qw.width_cm - (calc.hojaDescuento || 0)
        : qw.width_cm;
      const hAlto = calc
        ? qw.height_cm - (calc.hojaDescuento || 0)
        : qw.height_cm;
      const vAncho = calc
        ? qw.width_cm - (calc.vidrioDescuento || 0)
        : qw.width_cm;
      const vAlto = calc
        ? qw.height_cm - (calc.vidrioDescuento || 0)
        : qw.height_cm;

      return {
        ...qw,
        hojaAncho: hAncho,
        hojaAlto: hAlto,
        vidrioAncho: vAncho,
        vidrioAlto: vAlto,
        // CAMBIO: exponer como windowType para que processWindowsToReport lo encuentre
        windowType: qw.windowType,
        pvcColor: qw.pvcColor,
        glassColor: qw.glassColor,
      };
    });

    return this.processWindowsToReport(normalizedWindows);
  }

  async generateCutOptimizationReport(orderId: number) {
    const BAR_LENGTH = 580;
    // CAMBIO: orders -> order, window_type -> windowType
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { windows: { include: { windowType: true, pvcColor: true } } },
    });
    if (!order)
      throw new NotFoundException(`Pedido #${orderId} no encontrado.`);

    // CAMBIO: catalogo_perfiles -> catalogoPerfiles, perfil_marco -> perfilMarco, etc.
    // CAMBIO: map key usa window_type_id
    const profilesCatalog = await this.prisma.catalogoPerfiles.findMany({
      include: {
        perfilMarco: true,
        perfilHoja: true,
        perfilMosquitero: true,
        perfilBatiente: true,
        perfilTapajamba: true,
      },
    });
    const catalogMap = new Map(
      profilesCatalog.map((p) => [p.window_type_id, p]),
    );

    const individualCutList = new Map<
      string,
      { color: string; cuts: number[] }
    >();
    const combinableCutList = new Map<
      string,
      { color: string; hojaCuts: number[]; mosquiteroCuts: number[] }
    >();

    for (const window of order.windows) {
      // CAMBIO: window.window_type -> window.windowType
      if (!window.windowType || !window.pvcColor) continue;
      const catalogEntry = catalogMap.get(window.window_type_id!);
      if (!catalogEntry) continue;

      const windowQuantity = (window as any).quantity || 1;
      // CAMBIO: window.window_type.name -> window.windowType.name
      const isSlidingType = this.isSlidingWindowType(window.windowType.name);

      // CAMBIO: perfil_marco -> perfilMarco, etc.
      const profiles = [
        {
          type: 'MARCO',
          material: catalogEntry.perfilMarco,
          rule: catalogEntry.regla_marco,
        },
        {
          type: 'HOJA',
          material: catalogEntry.perfilHoja,
          rule: catalogEntry.regla_hoja,
        },
        {
          type: 'MOSQUITERO',
          material: catalogEntry.perfilMosquitero,
          rule: catalogEntry.regla_mosquitero,
        },
        {
          type: 'BATIENTE',
          material: catalogEntry.perfilBatiente,
          rule: catalogEntry.regla_batiente,
        },
        {
          type: 'TAPAJAMBA',
          material: catalogEntry.perfilTapajamba,
          rule: catalogEntry.regla_tapajamba,
        },
      ];

      for (const profile of profiles) {
        if (!profile.material || !profile.rule) continue;
        const individualCuts = this.getIndividualCuts(
          profile.rule,
          profile.type,
          window,
        );

        for (let i = 0; i < windowQuantity; i++) {
          if (
            isSlidingType &&
            (profile.type === 'HOJA' || profile.type === 'MOSQUITERO')
          ) {
            const hojaProfileName = catalogEntry.perfilHoja?.name;
            const mosquiteroProfileName = catalogEntry.perfilMosquitero?.name;
            if (!hojaProfileName || !mosquiteroProfileName) continue;

            const key = `${window.pvcColor.name}|${hojaProfileName}|${mosquiteroProfileName}`;
            if (!combinableCutList.has(key)) {
              combinableCutList.set(key, {
                color: window.pvcColor.name,
                hojaCuts: [],
                mosquiteroCuts: [],
              });
            }
            if (profile.type === 'HOJA') {
              combinableCutList.get(key)!.hojaCuts.push(...individualCuts);
            } else {
              combinableCutList
                .get(key)!
                .mosquiteroCuts.push(...individualCuts);
            }
          } else {
            const key = `${window.pvcColor.name}|${profile.material.name}`;
            if (!individualCutList.has(key))
              individualCutList.set(key, {
                color: window.pvcColor.name,
                cuts: [],
              });
            individualCutList.get(key)!.cuts.push(...individualCuts);
          }
        }
      }
    }

    const optimizationResult: any = {};

    for (const [key, value] of individualCutList.entries()) {
      const [color, profileName] = key.split('|');
      const optimizedBins = this.optimizeCuts(value.cuts, BAR_LENGTH);
      this.formatAndAddResult(
        optimizationResult,
        profileName,
        color,
        optimizedBins,
        BAR_LENGTH,
      );
    }

    for (const [key, value] of combinableCutList.entries()) {
      const [color, hojaProfileName, mosquiteroProfileName] = key.split('|');
      const { optimizedHojaBins, optimizedMosquiteroBins } =
        this.optimizeCombinedCuts(
          value.hojaCuts,
          value.mosquiteroCuts,
          BAR_LENGTH,
        );
      if (optimizedHojaBins.length > 0)
        this.formatAndAddResult(
          optimizationResult,
          hojaProfileName,
          color,
          optimizedHojaBins,
          BAR_LENGTH,
        );
      if (optimizedMosquiteroBins.length > 0)
        this.formatAndAddResult(
          optimizationResult,
          mosquiteroProfileName,
          color,
          optimizedMosquiteroBins,
          BAR_LENGTH,
        );
    }

    return optimizationResult;
  }

  private isSlidingWindowType(typeName: string): boolean {
    return typeName.toUpperCase().includes('CORREDIZA');
  }

  private formatAndAddResult(
    resultObj: any,
    profileName: string,
    color: string,
    bins: number[][],
    barLength: number,
  ) {
    if (!resultObj[profileName]) resultObj[profileName] = [];
    resultObj[profileName].push({
      color,
      totalBars: bins.length,
      bars: bins.map((bar, index) => {
        const totalUsed = bar.reduce((sum, cut) => sum + cut, 0);
        return {
          barNumber: index + 1,
          cuts: bar.sort((a, b) => b - a),
          totalUsed: Number(totalUsed.toFixed(1)),
          waste: Number((barLength - totalUsed).toFixed(1)),
          efficiency: Number(((totalUsed / barLength) * 100).toFixed(2)),
        };
      }),
    });
  }

  private optimizeCombinedCuts(
    hojaCuts: number[],
    mosquiteroCuts: number[],
    barLength: number,
  ) {
    const cutFrequencies = new Map<
      number,
      { hoja: number; mosquitero: number }
    >();
    hojaCuts.forEach((cut) => {
      const f = cutFrequencies.get(cut) || { hoja: 0, mosquitero: 0 };
      f.hoja++;
      cutFrequencies.set(cut, f);
    });
    mosquiteroCuts.forEach((cut) => {
      const f = cutFrequencies.get(cut) || { hoja: 0, mosquitero: 0 };
      f.mosquitero++;
      cutFrequencies.set(cut, f);
    });

    const finalHojaCuts: number[] = [];
    const finalMosquiteroCuts: number[] = [];

    for (const [cutLength, freqs] of cutFrequencies.entries()) {
      const numTriples = Math.min(Math.floor(freqs.hoja / 2), freqs.mosquitero);
      if (numTriples > 0) {
        for (let i = 0; i < numTriples; i++) {
          finalHojaCuts.push(cutLength, cutLength);
          finalMosquiteroCuts.push(cutLength);
        }
        freqs.hoja -= numTriples * 2;
        freqs.mosquitero -= numTriples;
      }
    }
    for (const [cutLength, freqs] of cutFrequencies.entries()) {
      for (let i = 0; i < freqs.hoja; i++) finalHojaCuts.push(cutLength);
      for (let i = 0; i < freqs.mosquitero; i++)
        finalMosquiteroCuts.push(cutLength);
    }

    return {
      optimizedHojaBins: this.optimizeCuts(finalHojaCuts, barLength),
      optimizedMosquiteroBins: this.optimizeCuts(
        finalMosquiteroCuts,
        barLength,
      ),
    };
  }

  private optimizeCuts(cuts: number[], barLength: number): number[][] {
    const sortedCuts = cuts.sort((a, b) => b - a);
    const bins: { cuts: number[]; remaining: number }[] = [];
    for (const cut of sortedCuts) {
      let placed = false;
      for (const bin of bins) {
        if (cut <= bin.remaining) {
          bin.cuts.push(cut);
          bin.remaining -= cut;
          placed = true;
          break;
        }
      }
      if (!placed) bins.push({ cuts: [cut], remaining: barLength - cut });
    }
    return bins.map((bin) => bin.cuts);
  }

  private getIndividualCuts(
    rule: string,
    profileType: string,
    window: Window,
  ): number[] {
    const useWindowMeasures =
      profileType === 'MARCO' || profileType === 'TAPAJAMBA';
    const width = useWindowMeasures ? window.width_cm : (window.hojaAncho ?? 0);
    const height = useWindowMeasures
      ? window.height_cm
      : (window.hojaAlto ?? 0);
    const multiplierMatch = rule.match(/\*(\d+)$/);
    const multiplier = multiplierMatch ? parseInt(multiplierMatch[1], 10) : 1;
    const cuts: number[] = [];

    if (rule.includes('SUMAR ANCHO Y MULTIPLICAR ALTO')) {
      cuts.push(width);
      for (let i = 0; i < multiplier; i++) cuts.push(height);
    } else if (rule.includes('ANCHO') && rule.includes('ALTO')) {
      const repeatCount = multiplier / 2;
      for (let i = 0; i < repeatCount; i++) cuts.push(width, height);
    } else if (rule.includes('ALTO')) {
      for (let i = 0; i < multiplier; i++) cuts.push(height);
    }

    return cuts.map((cut) => Number(cut.toFixed(1)));
  }

  private calculateProfileLength(
    rule: string,
    profileType: string,
    window: Window,
  ): number {
    const useWindowMeasures =
      profileType === 'MARCO' || profileType === 'TAPAJAMBA';
    const currentWidth = useWindowMeasures
      ? window.width_cm
      : (window.hojaAncho ?? 0);
    const currentHeight = useWindowMeasures
      ? window.height_cm
      : (window.hojaAlto ?? 0);
    const multiplierMatch = rule.match(/\*(\d+)$/);
    const multiplier = multiplierMatch ? parseInt(multiplierMatch[1], 10) : 1;

    if (rule.includes('SUMAR ANCHO Y MULTIPLICAR ALTO'))
      return currentWidth + currentHeight * multiplier;
    let length = 0;
    if (rule.includes('ANCHO') && rule.includes('ALTO'))
      length = currentWidth + currentHeight;
    else if (rule.includes('ALTO')) length = currentHeight;
    return length * multiplier;
  }
}
