import { Controller, Get, Param, ParseIntPipe, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ReportsService } from './reports.service';

@UseGuards(JwtAuthGuard)
@Controller('reports')
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  // ✨ Creamos nuestra ruta personalizada ✨
  // Cuando el frontend pida GET /reports/order/1/profiles, esta función se ejecutará.
  @Get('order/:orderId/profiles')
  generateProfilesReport(
    @Param('orderId', ParseIntPipe) orderId: number, // NestJS se asegura de que el ID sea un número válido
  ) {
    return this.reportsService.generateProfilesReport(orderId);
  }

  @Get('quotation/:quotationId/profiles')
  generateQuotationProfilesReport(
    @Param('quotationId', ParseIntPipe) quotationId: number,
  ) {
    // Llamaremos a una nueva función que crearemos en el service
    return this.reportsService.generateProfilesReportByQuotation(quotationId);
  }

  // ✨ AÑADE ESTE NUEVO ENDPOINT PARA EL OPTIMIZADOR ✨
  @Get('order/:orderId/optimize-cuts')
  generateCutOptimizationReport(
    @Param('orderId', ParseIntPipe) orderId: number,
  ) {
    // Llamará a una nueva función en nuestro servicio
    return this.reportsService.generateCutOptimizationReport(orderId);
  }
}
