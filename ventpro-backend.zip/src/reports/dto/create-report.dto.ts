export class CreateReportDto {}
