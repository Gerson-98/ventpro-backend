// RUTA: ventpro-backend/src/main.ts
import { NestFactory } from '@nestjs/core';
import { join } from 'path';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  // Tu "Lista VIP" actualizada con el subdominio de la API y el dominio principal
  const whitelist = [
    'http://localhost:5173',
    'https://ventprofesional.com',
    'https://www.ventprofesional.com',
    'https://peachpuff-cat-711358.hostingersite.com',
  ];

  app.enableCors({
    origin: function (origin, callback) {
      if (!origin || whitelist.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error('No permitido por la política de CORS'));
      }
    },
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    allowedHeaders: ['Content-Type', 'Authorization'], // Agregado por seguridad
    credentials: true,
  });

  // app.useStaticAssets(join(__dirname, '..', 'public'));

  // ✅ Escucha en process.env.PORT y acepta conexiones de todas las interfaces ('0.0.0.0')
  const port = process.env.PORT || 3000;
  await app.listen(port);

  console.log(`✅ Backend listo en el puerto ${port}`);
}
bootstrap();
