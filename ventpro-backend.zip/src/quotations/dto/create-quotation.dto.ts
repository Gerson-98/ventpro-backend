// RUTA: ventpro-backend/src/quotations/dto/create-quotation.dto.ts

import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsNotEmpty,
  IsNumber,
  IsObject, // ✨ 1. Importamos IsObject
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class QuotationWindowDto {
  @IsNumber()
  @IsOptional()
  id?: number; // Para identificar ventanas existentes en UPDATE

  @IsString()
  @IsOptional()
  design_image_url?: string;

  @IsString()
  @IsOptional()
  displayName?: string;

  @IsNumber()
  @IsNotEmpty()
  width_m: number;

  @IsNumber()
  @IsNotEmpty()
  height_m: number;

  @IsOptional()
  @IsNumber()
  quantity?: number;

  @IsOptional()
  @IsNumber()
  price_per_m2?: number;

  @IsNumber()
  @IsNotEmpty()
  window_type_id: number;

  @IsNumber()
  @IsNotEmpty()
  color_id: number;

  @IsNumber()
  @IsNotEmpty()
  glass_color_id: number;

  // ✨ 2. AÑADIMOS EL CAMPO options AL DTO
  @IsObject()
  @IsOptional()
  options?: any;
}

export class CreateQuotationDto {
  @IsString()
  @IsNotEmpty()
  project: string;

  @IsNumber()
  @IsNotEmpty()
  price_per_m2: number;

  @IsNumber()
  @IsOptional()
  clientId?: number;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => QuotationWindowDto)
  windows: QuotationWindowDto[];

  include_iva?: boolean; // Agrega esto
  total_price?: number; // Agrega esto
}

export class ConfirmQuotationDto {
  @IsDateString()
  @IsNotEmpty()
  installationStartDate: string;

  @IsDateString()
  @IsNotEmpty()
  installationEndDate: string;
}
