export class Quotation {}
