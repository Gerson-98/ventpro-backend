export class WindowTypeOption {}
