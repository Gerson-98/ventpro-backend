export class CreateGlassColorDto {}
