export class GlassColor {}
