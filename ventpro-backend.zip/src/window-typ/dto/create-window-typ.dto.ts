export class CreateWindowTypDto {}
