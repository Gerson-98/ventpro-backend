import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
  UpdateOrderDto,
  RescheduleOrderDto,
  UpdateOrderStatusDto,
} from './dto/update-order.dto';
import { OrderStatus, QuotationStatus } from '@prisma/client';

@Injectable()
export class OrdersService {
  constructor(private prisma: PrismaService) {}

  create(data: {
    project: string;
    clientId: number;
    total: number;
    status?: string;
    generatedFromQuotationId?: number;
  }) {
    const statusEnum = data.status
      ? OrderStatus[data.status.toUpperCase().replace(' ', '_')]
      : OrderStatus.EN_PROCESO;

    // CAMBIO: orders -> order, clients -> client
    return this.prisma.order.create({
      data: {
        project: data.project,
        total: Number(data.total),
        status: statusEnum || OrderStatus.EN_PROCESO,
        client: { connect: { id: Number(data.clientId) } },
        ...(data.generatedFromQuotationId && {
          generatedFromQuotation: {
            connect: { id: Number(data.generatedFromQuotationId) },
          },
        }),
      },
      include: {
        client: true,
        windows: true,
        generatedFromQuotation: true,
      },
    });
  }

  findAll() {
    // CAMBIO: orders -> order, clients -> client
    return this.prisma.order.findMany({
      include: {
        client: true,
        _count: { select: { windows: true } },
      },
      orderBy: { id: 'desc' },
    });
  }

  findOne(id: number) {
    // CAMBIO: orders -> order, clients -> client, window_type -> windowType
    return this.prisma.order.findUnique({
      where: { id },
      include: {
        client: true,
        generatedFromQuotation: true,
        windows: {
          include: {
            windowType: true,
            pvcColor: true,
            glassColor: true,
          },
        },
      },
    });
  }

  update(
    id: number,
    data: {
      project?: string;
      total?: number;
      status?: string;
      include_iva?: boolean;
    },
  ) {
    const statusEnum = data.status
      ? OrderStatus[
          data.status
            .toUpperCase()
            .replace(' ', '_') as keyof typeof OrderStatus
        ]
      : undefined;

    // CAMBIO: orders -> order, clients -> client
    return this.prisma.order.update({
      where: { id },
      data: {
        project: data.project,
        total: data.total ? Number(data.total) : undefined,
        status: statusEnum,
        include_iva: data.include_iva,
      },
      include: {
        client: true,
        windows: { include: { pvcColor: true, glassColor: true } },
        generatedFromQuotation: true,
      },
    });
  }

  remove(id: number) {
    // CAMBIO: orders -> order
    return this.prisma.order.delete({ where: { id } });
  }

  async findScheduled() {
    // CAMBIO: orders -> order
    return this.prisma.order.findMany({
      where: { installationStartDate: { not: null } },
      select: {
        id: true,
        project: true,
        installationStartDate: true,
        installationEndDate: true,
        status: true,
      },
      orderBy: { installationStartDate: 'asc' },
    });
  }

  async updateOrderTotal(orderId: number) {
    // CAMBIO: orders -> order
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { windows: true },
    });
    if (!order) return;

    const newTotal = order.windows.reduce(
      (sum, win) => sum + (Number(win.price) || 0),
      0,
    );
    return this.prisma.order.update({
      where: { id: orderId },
      data: { total: newTotal },
    });
  }

  async reschedule(id: number, rescheduleOrderDto: RescheduleOrderDto) {
    const { installationStartDate, installationEndDate } = rescheduleOrderDto;
    // CAMBIO: orders -> order
    const order = await this.prisma.order.findUnique({ where: { id } });
    if (!order)
      throw new NotFoundException(`Pedido con ID #${id} no encontrado.`);

    return this.prisma.order.update({
      where: { id },
      data: {
        installationStartDate: new Date(installationStartDate),
        installationEndDate: new Date(installationEndDate),
      },
    });
  }

  async updateStatus(id: number, updateOrderStatusDto: UpdateOrderStatusDto) {
    const newStatusKey = updateOrderStatusDto.status
      .toUpperCase()
      .replace(' ', '_');
    const newStatus = OrderStatus[newStatusKey];
    if (!newStatus) throw new BadRequestException('Estado no válido');

    // CAMBIO: orders -> order
    const order = await this.prisma.order.findUnique({
      where: { id },
      select: { generatedFromQuotationId: true },
    });
    if (!order)
      throw new NotFoundException(`Pedido con ID #${id} no encontrado.`);

    if (newStatus === OrderStatus.CANCELADO && order.generatedFromQuotationId) {
      const quotationIdToRelease = order.generatedFromQuotationId;

      return this.prisma.$transaction(async (tx) => {
        // CAMBIO: tx.orders -> tx.order
        const updatedOrder = await tx.order.update({
          where: { id },
          data: { status: newStatus },
        });

        // CAMBIO: status: 'en proceso' -> QuotationStatus.en_proceso
        await tx.quotation.update({
          where: { id: quotationIdToRelease },
          data: {
            status: QuotationStatus.en_proceso,
            generatedOrder: { disconnect: true },
          },
        });

        return updatedOrder;
      });
    }

    // CAMBIO: orders -> order
    return this.prisma.order.update({
      where: { id },
      data: { status: newStatus },
      include: {
        client: true,
        generatedFromQuotation: true,
        windows: true,
      },
    });
  }
}
